package com.csusm.cs481.journalapp;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TimePicker;

import java.util.Calendar;

public class AddEntry extends AppCompatActivity {

    //Reference for Edit Texts
    EditText etTitle;
    EditText etDescription;
    EditText etLocation;
    EditText etDate;

    //Reference for buttons
    Button btnExitAdd;
    Button btnAddAdd;

    //For the time
    private Calendar calendarTime;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_entry);

        etTitle = findViewById(R.id.edTitleEntry);
        etDate = findViewById(R.id.etDate);
        etDescription = findViewById(R.id.etDescriptionEntry);
        etLocation = findViewById(R.id.etLocation);

        mDisplayDate = (Button) findViewById(R.id.btnDateTaskObject);
        mDisplayDate.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                Calendar cal = Calendar.getInstance();
                year = cal.get(Calendar.YEAR);
                month = cal.get(Calendar.MONTH);
                day = cal.get(Calendar.DAY_OF_MONTH);

                DatePickerDialog dialog = new DatePickerDialog(
                        AddTask.this,
                        android.R.style.Theme_DeviceDefault_Dialog,//not sure if this is the correct theme
                        mDateSetListener,
                        year, month, day);

                //dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                dialog.show();
            }
            mDateSetListener = new DatePickerDialog.OnDateSetListener() {
                @Override
                public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                    //This is where it would call the server to get the data for the day here
                    month = month + 1;
                    String date = month + "/" + dayOfMonth + "/" + year;
                    dayPass = dayOfMonth;
                    yearPass = year;
                    monthPass = month;
                    mDisplayDate.setText(date);

                }
            };

        });
